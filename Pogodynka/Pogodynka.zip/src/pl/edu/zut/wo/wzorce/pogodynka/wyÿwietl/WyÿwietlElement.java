package pl.edu.zut.wo.wzorce.pogodynka.wyświetl;

public interface WyświetlElement {
	public void wyświetl();
}
